import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/user_model.dart';

class DatabaseHelper {
  // Singleton intance
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  // Configuration variables
  static Database? _database;
  final String databaseName = 'notes_5sia3.db';
  final int databaseVersion = 1;

  // Create user  table
  final String createUserTable = '''
    CREATE TABLE users (
      userId INTEGER PRIMARY KEY AUTOINCREMENT,
      userName TEXT UNIQUE NOT NULL,
      userPassword TEXT NOT NULL
    )
  ''';
  // Create note table
  final String createNoteTable = '''
    CREATE TABLE notes (
      noteId INTEGER PRIMARY KEY AUTOINCREMENT,
      noteTitle TEXT NOT NULL,
      noteContent TEXT NOT NULL,
      createAt TEXT DEFAULT CURRENT_TIMESTAMP
    )
  ''';

  // Initialize the database
  Future<Database> initDB() async {
    print('Initializing database...');
    try {
      final databasePath = await getDatabasesPath();
      print('Database path: $databasePath');
      final path = join(databasePath, databaseName);
      print('Database full path: $path');

      return openDatabase(
        path,
        version: databaseVersion,
        onCreate: (db, version) async {
          print('Creating database tables...');
          await db.execute(createUserTable);
          print('User table created');
          await db.execute(createNoteTable);
          print('Note table created');
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          // Handle database upgrades if needed
          if (oldVersion < newVersion) {
            // Add upgrade logic here if schema changes in the future
          }
        },
      );
    } catch (e) {
      print('Error initializing database: $e');
      rethrow;
    }
  }

  // Get the database instance
  Future<Database> get database async {
    print('Getting database instance...');
    if (_database != null) {
      print('Using existing database instance');
      return _database!;
    }
    print('Initializing new database instance');
    try {
      _database = await initDB();
      print('Database instance initialized');
      return _database!;
    } catch (e) {
      print('Error getting database instance: $e');
      rethrow;
    }
  }

  // Login Method
  Future<bool> login(UserModel user) async {
    print('Attempting login for user: ${user.userName}');
    final db = await database;
    print('Database instance obtained for login');
    final result = await db.query(
      'users',
      where: 'userName = ? AND userPassword = ?',
      whereArgs: [user.userName, user.userPassword],
    );
    print('Login query result: ${result.length} rows');
    return result.isNotEmpty;
  }
 
  // Create Account Method
  Future<int> createAccount(UserModel user) async {
    try {
      print('Creating account for user: ${user.userName}');
      final Database db = await database;
      print('Database instance obtained, inserting user...');
      final result = await db.insert('users', user.toMap());
      print('User inserted with result: $result');
      return result;
    } catch (e) {
      print('Database error: $e'); // Log the actual error for debugging
      // Handle specific SQLite exceptions
      if (e.toString().contains('UNIQUE constraint failed')) {
        throw Exception('Username already exists');
      }
      throw Exception('Failed to create account: ${e.toString()}');
    }
  }
}
